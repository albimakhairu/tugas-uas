<?php 
	echo $card_info;
	echo $map;
?>