                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-2 mt-auto">
                    <div class="container-fluid">
                        <!-- <div class="d-flex align-items-center justify-content-between small"> -->
                        <div class="text-right">
                            <!-- <div class="text-muted">{cprg}</div> -->
                            <!-- <div>
                                <a href="{cprg3}" target="blank_">{cprg2}</a>
                            </div> -->
                            <img src="public/assets/images/logo/ngawi.jpeg" class="img-thumbnail" width="50px" title="Kabupaten Ngawi">
                            <img src="public/assets/images/logo/logo_menhub.png" class="img-thumbnail" width="50px" title="Kementrian Perhubungan">
                            <img src="public/assets/images/logo/ktj.jpeg" class="img-thumbnail" width="50px" title="Politeknik Keselamatan Transportasi Jalan">
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="{public}plugins/jquery/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="{public}plugins/bootstrap-4.4.1-dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    </body>
</html>
