<div class="col-lg-12">
    <div class="row">
        <div class="col-xl-6 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <i class="fas fa-list"></i>
                    Jumlah Jalan <span class="badge badge-warning badge-pill" id="jml_jalan"></span>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-md-6">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">
                    <i class="fas fa-list"></i>
                    Jumlah Rambu <span class="badge badge-warning badge-pill" id="jml_rambu"></span>
                </div>
            </div>
        </div>
        <!-- <div class="col-xl-3 col-md-3">
            <div class="card bg-info text-white mb-4">
                <div class="card-body">
                    <i class="fas fa-list"></i>
                    Jumlah Stok <span class="badge badge-warning badge-pill" id="">20</span>
                </div>            
            </div>
        </div>
        <div class="col-xl-3 col-md-3">
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <i class="fas fa-list"></i>
                    Jumlah Kasbon <span class="badge badge-warning badge-pill" id="">3</span>
                </div>            
            </div>
        </div> -->
    </div>
</div>