<!-- SB-ADMIN -->
<link href="<?=asset_url();?>vendors/sb-admin/styles.css" rel="stylesheet" />

<!-- JQUERY UI -->
<link href="<?=asset_url();?>vendors/jquery-ui-1.12.1/jquery-ui.min.css">
<link rel="stylesheet" href="<?=asset_url();?>vendors/jquery-ui-themes-1.12.1/themes/blitzer/jquery-ui.min.css">

<!-- <link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css"> -->

<!-- DATA TABLES -->
<link href="<?=asset_url();?>vendors/DataTables/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
<link rel="stylesheet" type="text/css" href="<?=asset_url();?>vendors/DataTables/Responsive-2.2.3/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="<?=asset_url();?>vendors/DataTables/Responsive-2.2.3/css/responsive.jqueryui.min.css">

<!-- NGAJINGODING.COM.CSS -->
<link rel="stylesheet" type="text/css" href="<?=asset_url();?>css/semutbasah.css">

<!-- FONT-AWESOME -->
<script src="<?=asset_url();?>vendors/font-awesome/5.11.2/js/all.min.js"></script>